import sys
import os
import subprocess
import argparse
import psycopg2

dbname = 'test_db'

def run_odoo_tests(module_name):
    tag_name = str(module_name).replace('-', '_')
    print(f'### RUN TESTS | {module_name}')
    
    command = [
        'python3.11', '/home/fanuelramos/Odoo/16/odoo/odoo.py',
        '-c', '/home/fanuelramos/Odoo/16/odooe.conf',
        '-d', dbname,
        '-i', module_name,
        '--test-enable',
        #'--log-level=debug',
        '--stop-after-init',
        f'--log-handler={module_name}:',
        f'--test-tags={tag_name}',
    ]

    process = subprocess.run(command)
    
    if process.returncode != 0:
        print(f"❌ Tests failed for module: {module_name}")
        delete_database_tests()
        sys.exit(process.returncode)

def delete_database_tests():
    try:
        conn = psycopg2.connect(
            dbname="postgres",
            user="odoo",
            password="Commander",
            host="localhost"
        )
        conn.autocommit = True
        cursor = conn.cursor()
        cursor.execute(f"DROP DATABASE IF EXISTS {dbname};")
        print(f"✅ Database {dbname} deleted successfully.")
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"❌ Error deleting database: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Executar testes para os módulos especificados.')
    parser.add_argument('tags', nargs='*', help='Lista de tags de módulos a serem testados')
    
    args = parser.parse_args()
    
    try:
        run_odoo_tests('appraisal_kpi')
        delete_database_tests()
        sys.exit(0)
    except Exception as e:
        print(f"❌ Erro durante a execução dos testes: {e}")
        delete_database_tests()
        sys.exit(1)
